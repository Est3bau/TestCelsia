function crearCliente() {
    debugger
    const identificacion  = document.getElementById('identificacion').value;
    const nombres = document.getElementById('nombres').value;
    const apellidos = document.getElementById('apellidos').value;
    const tipoIdentificacion = document.getElementById('tipoIdentificacion').value;
    const fechaNacimiento = document.getElementById('fechaNacimiento').value;
    const numeroCelular = document.getElementById('numeroCelular').value;
    const correoElectronico  = document.getElementById('correoElectronico').value;
    
    fetch('/cliente', {
        method: 'POST',
        headers: {  
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ identificacion, nombres ,apellidos,tipoIdentificacion,
            fechaNacimiento,numeroCelular,correoElectronico
        }),
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        location.reload();
    });
}


function crearServicio() {
    const identificacion = document.getElementById('identificacion').value;
    const servicio = document.getElementById('servicio').value;
    const fechaInicio = document.getElementById('fechaInicio').value;
    const ultimaFacturacion = document.getElementById('ultimaFacturacion').value;
    const ultimoPago = document.getElementById('ultimoPago').value;

    fetch('/servicio', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ identificacion, servicio,fechaInicio, ultimaFacturacion,ultimoPago }),
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        location.reload();
    });
}
