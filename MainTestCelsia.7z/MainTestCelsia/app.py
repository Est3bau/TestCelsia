from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///crud.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Modelo Clientes
class Cliente(db.Model):
    identificacion = db.Column(db.String(20), primary_key=True, nullable=False)
    nombres = db.Column(db.String(80), nullable=False)
    apellidos = db.Column(db.String(80), nullable=False)
    tipoIdentificacion = db.Column(db.String(2), nullable=False)
    fechaNacimiento = db.Column(db.Date, nullable=False)
    numeroCelular = db.Column(db.Integer, nullable=False)  
    correoElectronico = db.Column(db.String(80), nullable=False) 

    servicios = db.relationship("Servicio", back_populates="cliente", cascade="all, delete-orphan")

# Modelo Servicio
class Servicio(db.Model):
    identificacion = db.Column(db.String(20), db.ForeignKey('cliente.identificacion', onupdate="CASCADE", ondelete="NO ACTION"), primary_key=True, nullable=False)
    servicio = db.Column(db.String(80),nullable=False)
    fechaInicio = db.Column(db.Date, nullable=False)
    ultimaFacturacion = db.Column(db.Date, nullable=False)
    ultimoPago = db.Column(db.Integer, nullable=False, default=0)

    # Relación con la tabla Cliente
    cliente = db.relationship("Cliente", back_populates="servicios")

    
# Crear las tablas
with app.app_context():
    db.create_all()

# Ruta para cargar el Frontend
@app.route('/')
def index():
    clientes = Cliente.query.all()
    servicios = Servicio.query.all()
    return render_template('index.html', clientes=clientes, servicios=servicios)

# CRUD para Clientes
@app.route('/cliente', methods=['POST'])
def create_cliente():
    data = request.json
    nuevo_cliente = Cliente(identificacion=data['identificacion'], nombres=data['nombres'],
                            apellidos=data['apellidos'],tipoIdentificacion=data['tipoIdentificacion'],
                            fechaNacimiento=data['fechaNacimiento'],numeroCelular=data['numeroCelular'],
                            correoElectronico=data['correoElectronico'])
    db.session.add(nuevo_cliente)
    db.session.commit()
    return jsonify({'message': 'Cliente creado exitosamente'})

@app.route('/cliente/<identificacion>', methods=['PUT'])
def update_cliente(cedula):
    cliente = Cliente.query.get(identificacion)
    if cliente:
        data = request.json
        cliente.nombres = data['nombres']
        db.session.commit()
        return jsonify({'message': 'Cliente actualizado exitosamente'})
    return jsonify({'message': 'Cliente no encontrado'}), 404

@app.route('/cliente/<identificacion>', methods=['DELETE'])
def delete_cliente(cedula):
    cliente = Cliente.query.get(identificacion)
    if cliente:
        db.session.delete(cliente)
        db.session.commit()
        return jsonify({'message': 'Cliente eliminado exitosamente'})
    return jsonify({'message': 'Cliente no encontrado'}), 404

# CRUD para Servicios
@app.route('/servicio', methods=['POST'])
def create_servicio():
    data = request.json
    nuevo_servicio = Servicio(servicio=data['servicio'],
                              fechaInicio=data['fechaInicio'],ultimaFacturacion=data['ultimaFacturacion'],
                              ultimoPago=data['ultimoPago'])
    db.session.add(nuevo_servicio)
    db.session.commit()
    return jsonify({'message': 'Servicio creado exitosamente'})

@app.route('/servicio/<id>', methods=['DELETE'])
def delete_servicio(identificacion):
    servicio = Servicio.query.get(id)
    if servicio:
        db.session.delete(servicio)
        db.session.commit()
        return jsonify({'message': 'Servicio eliminado exitosamente'})
    return jsonify({'message': 'Servicio no encontrado'}), 404

if __name__ == '__main__':
    app.run(debug=True)
